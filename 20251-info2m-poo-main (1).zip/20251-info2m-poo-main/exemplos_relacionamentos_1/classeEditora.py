class Editora:

    def __init__(self, nomeEditora):
        self.nome = nomeEditora