arquivo = open("manipulacao_arquivos/arquivo_teste.txt", 
               "w")

arquivo.write("Escrevi alguma coisa no arquivo")

arquivo.close()