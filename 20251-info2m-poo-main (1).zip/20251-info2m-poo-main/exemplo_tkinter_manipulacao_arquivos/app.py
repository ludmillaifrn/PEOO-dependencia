from janela_principal import JanelaPrincipal


def run():
    """
    Arquivo inicial da aplicacao. Instancia a janela principal.
    """
    JanelaPrincipal()
    

run()