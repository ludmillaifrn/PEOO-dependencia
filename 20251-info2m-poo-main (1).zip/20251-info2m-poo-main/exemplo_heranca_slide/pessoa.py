class Pessoa:
    def __init__(self, nomePessoa, cpfPessoa):
        self.nome = nomePessoa
        self.cpf = cpfPessoa