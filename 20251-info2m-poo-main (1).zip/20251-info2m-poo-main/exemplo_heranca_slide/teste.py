from professor import Professor

p = Professor("leo", "1234567", 12345, 4000, "POO")

print(p)