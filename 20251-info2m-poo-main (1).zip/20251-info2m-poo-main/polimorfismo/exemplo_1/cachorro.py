from animal import Animal

class Cachorro(Animal):
    def emitir_som(self):
        return "Cachorro latindo"