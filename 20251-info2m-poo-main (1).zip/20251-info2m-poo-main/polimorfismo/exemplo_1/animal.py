class Animal:
    def emitir_som(self):
        return "Algum som genérico"