class Transporte():
    def __init__(self, distancia):
        self.distancia = distancia

    def calcular_tempo(self):
        return -1