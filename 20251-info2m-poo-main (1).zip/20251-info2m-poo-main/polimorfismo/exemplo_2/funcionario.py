from abc import ABC

class Funcionario(ABC):
    def calcular_comissao(self, valorVenda):
        pass