from abc import ABC

class AbstrataSemMetodos(ABC):
    pass

# Tentativa de instanciar a classe AbstrataSemMetodos
# Gera um erro TypeError
objeto = AbstrataSemMetodos()