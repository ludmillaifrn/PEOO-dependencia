from circulo import Circulo
from triangulo import Triangulo

c = Circulo(3)

# print("area:", c.area())
print("perimetro:", c.perimetro())

t = Triangulo(3, 4)

print("area:", t.area())
print("perimetro:", t.perimetro())