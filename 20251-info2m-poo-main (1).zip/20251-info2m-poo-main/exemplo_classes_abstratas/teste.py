from pessoa import Pessoa

p = Pessoa("Leo")

print(p.imprimir_nome())