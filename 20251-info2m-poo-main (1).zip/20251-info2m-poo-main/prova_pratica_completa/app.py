from janela_principal import JanelaPrincipal


def run():
    JanelaPrincipal()
    

run()