doguinho = Cachorro("Rex", 5, 12)
gatinho = Gato("Mimi", 3)

doguinho.latir()
gatinho.miar()

print(doguinho.nome, doguinho.idade)
print(gatinho.nome, gatinho.idade)