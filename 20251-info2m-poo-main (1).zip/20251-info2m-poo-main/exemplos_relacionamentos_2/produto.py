class Produto:

    def __init__(self, codigoProduto, descricaoProduto, precoProduto):
        self.codigo = codigoProduto
        self.descricao = descricaoProduto
        self.preco = precoProduto